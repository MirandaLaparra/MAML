export class Producto {
    id:number;
    nombre:String;
    imagen:String;
    precio:number;
    unidadesDisponibles:number;
    cantidadAComprar:number;
}
