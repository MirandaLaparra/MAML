export class Usuario {
    nombre:String;
    correo:String;
    contrasena:String;
}
